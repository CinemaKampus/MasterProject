<ul class="sidebar navbar-nav">
            <li class="nav-item active">
               <a class="nav-link" href="login/logout.php">
               <i class="fas fa-fw fa-home"></i>
               <span>Home</span>
               </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="login/logout.php">
               <i class="fas fa-fw fa-users"></i>
               <span>Channels</span>
               </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="login/logout.php">
               <i class="fas fa-fw fa-user-alt"></i>
               <span>Single Channel</span>
               </a>
            </li>
            <li class="nav-item">
               <a class="nav-link" href="login/logout.php">
               <i class="fas fa-fw fa-video"></i>
               <span>Video Page</span>
               </a>
            </li>
           
            <li class="nav-item">
               <a class="nav-link" href="login/logout.php">
               <i class="fas fa-fw fa-history"></i>
               <span>History Video</span>
               </a>
            </li>
           
         </ul>