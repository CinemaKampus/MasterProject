<?php
$koneksi = mysqli_connect('localhost','root','','db_cinema');
// Mengecek koneksi
// if(!$koneksi){
//     die("Koneksi Gagal:". mysqli_connect_error());
// }
// else{
//     echo "Koneksi Behasil";
// }
?>